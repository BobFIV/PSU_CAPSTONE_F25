from django.shortcuts import render
from django.http import JsonResponse

def home(request):
    return render(request, "ui/dashboard.html")

def latest_data(request):
    return JsonResponse({"device": "esp32", "value": 42})
