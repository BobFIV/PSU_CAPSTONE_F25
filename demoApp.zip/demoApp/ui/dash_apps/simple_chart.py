from django_plotly_dash import DjangoDash
from dash import dcc, html   # ✅ modern Dash imports

app = DjangoDash("SimpleChart")

app.layout = html.Div([
    html.H3("Sensor Values"),
    dcc.Graph(
        id="line-chart",
        figure={
            "data": [
                {"x": [1, 2, 3], "y": [10, 20, 30], "type": "line", "name": "example"},
            ],
            "layout": {"title": "Example Data"}
        }
    )
])
